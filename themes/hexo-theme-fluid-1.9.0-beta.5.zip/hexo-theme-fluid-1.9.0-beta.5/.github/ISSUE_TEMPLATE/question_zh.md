---
name: 问题求助
about: 提出一个使用过程中遇到的问题，需要得到帮助
---

#### 请确认
- [ ] 是当前最新的 [Release 版本](https://github.com/fluid-dev/hexo-theme-fluid/releases)
- [ ] 在 [用户指南](https://hexo.fluid-dev.com/docs/) 中没有找到解决办法

#### 问题描述
<!--
例如，在使用 xxx 时出现了 xxx 报错。
如果是页面问题，需要提供浏览器版本（如果本地样式没问题，部署后有问题，请清除浏览器缓存）。
-->
